package Exercicio;

public class Entrega {
    String codigoVenda;
    String produto;
    long inicioEntrega;

    public Entrega(String codigoVenda, String produto, long inicioEntrega) {
        this.codigoVenda = codigoVenda;
        this.produto = produto;
        this.inicioEntrega = inicioEntrega;
    }
}
